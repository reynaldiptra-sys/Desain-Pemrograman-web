<?php
$page_title = "Tambah Anggota";
include __DIR__ . '/../includes/header.php';
?>
        <form id="form-tambah" method="post" action="proses_tambah.php">
            <p>
                <label for="nama">Nama</label><br>
                <input type="text" id="nama" name="nama" required>
            </p>
            <p>
                <label for="no_anggota">No. Anggota</label><br>
                <input type="text" id="no_anggota" name="no_anggota" required>
            </p>
            <p>
                <label for="alamat">Alamat</label><br>
                <input type="text" id="alamat" name="alamat">
            </p>
            <p>
                <label for="no_hp">No. HP</label><br>
                <input type="text" id="no_hp" name="no_hp">
            </p>
            <p>
                <label for="email">Email</label><br>
                <input type="email" id="email" name="email">
            </p>
            <p>
                <button type="submit">Simpan</button>
            </p>
        </form>
<?php include __DIR__ . '/../includes/footer.php'; ?>
